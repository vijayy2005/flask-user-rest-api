
# Flask User REST API

A simple REST API built with Flask for managing users.

## Features
- GET all users
- GET user by ID
- POST create user
- PUT update user
- DELETE user

## Installation
```bash
pip install -r requirements.txt
python app.py
```

## Test Endpoints
Use Postman or curl.

Base URL:
http://127.0.0.1:5000
